﻿using EmployeeTask.Models;
using EmployeeTask.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeTask.Controllers
{
    [Route("api/genders")]
    [ApiController]
    public class GenderController : ControllerBase
    {
        private readonly IGenderService _genderService;

        public GenderController(IGenderService genderService)
        {
            _genderService = genderService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Gender>>> GetAllGenders()
        {
            var genders = await _genderService.GetAllGendersAsync();
            return Ok(genders);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Gender>> GetGenderById(Int16 id)
        {
            var gender = await _genderService.GetGenderByIdAsync(id);
            if (gender == null)
            {
                return NotFound();
            }
            return Ok(gender);
        }

        [HttpPost]
        public async Task<ActionResult<Gender>> CreateGender([FromBody] Gender gender)
        {
            try
            {
                var createdGender = await _genderService.CreateGenderAsync(gender);
                return CreatedAtAction(nameof(GetGenderById), new { id = createdGender.GenderId }, createdGender);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateGender(Int16 id, [FromBody] Gender gender)
        {
            try
            {
                gender.GenderId = id; // Ensure the correct gender ID
                await _genderService.UpdateGenderAsync(gender);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGender(Int16 id)
        {
            try
            {
                await _genderService.DeleteGenderAsync(id);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
