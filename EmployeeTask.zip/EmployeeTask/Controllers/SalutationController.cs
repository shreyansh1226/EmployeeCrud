﻿using EmployeeTask.Models;
using EmployeeTask.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeTask.Controllers
{
    [Route("api/salutations")]
    [ApiController]
    public class SalutationController : ControllerBase
    {
        private readonly ISalutationService _salutationService;

        public SalutationController(ISalutationService salutationService)
        {
            _salutationService = salutationService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Salutation>>> GetAllSalutations()
        {
            var salutations = await _salutationService.GetAllSalutationsAsync();
            return Ok(salutations);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Salutation>> GetSalutationById(Int16 id)
        {
            var salutation = await _salutationService.GetSalutationByIdAsync(id);
            if (salutation == null)
            {
                return NotFound();
            }
            return Ok(salutation);
        }

        [HttpPost]
        public async Task<ActionResult<Salutation>> CreateSalutation([FromBody] Salutation salutation)
        {
            try
            {
                var createdSalutation = await _salutationService.CreateSalutationAsync(salutation);
                return CreatedAtAction(nameof(GetSalutationById), new { id = createdSalutation.SalutationId }, createdSalutation);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateSalutation(Int16 id, [FromBody] Salutation salutation)
        {
            try
            {
                salutation.SalutationId = id; // Ensure the correct salutation ID
                await _salutationService.UpdateSalutationAsync(salutation);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSalutation(Int16 id)
        {
            try
            {
                await _salutationService.DeleteSalutationAsync(id);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
