﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Reflection;
using EmployeeTask.Models;

namespace EmployeeTask
{
    public class Employee
    {
        [Key]
        public int EmployeeId { get; set; }
        [Required]
        [MaxLength(6)]
        public string EmployeeCode { get; set; }

        [Required]
        public Int16 SalutationId { get; set; }

        [ForeignKey("SalutationId")]
        public Salutation Salutation { get; set; }

        [Required]
        public Int16 DepartmentId { get; set; }

        [ForeignKey("DepartmentId")]
        public Department Department { get; set; }

        [Required]
        [MaxLength(128)]
        public string FirstName { get; set; }

        [MaxLength(64)]
        public string? MiddleName { get; set; }

        [MaxLength(64)]
        public string? LastName { get; set; }

        [MaxLength(128)]
        public string DisplayName { get; set; }

        [MaxLength(128)]
        public string FatherName { get; set; }

        [MaxLength(128)]
        public string? MotherName { get; set; }

        [MaxLength(128)]
        public string? SpouseName { get; set; }

        [Required]
        public Int16 GenderId { get; set; }

        [ForeignKey("GenderId")]
        public Gender Gender { get; set; }

        [Required]
        public bool MaritalStatus { get; set; }

        [Required]
        public DateTime DOB { get; set; }

        public DateTime? DOJ { get; set; }

        [MaxLength(10)]
        public string? PanNo { get; set; }

        [MaxLength(12)]
        public string AadharNo { get; set; }

        [MaxLength]
        public string? Description { get; set; }
    }
}
