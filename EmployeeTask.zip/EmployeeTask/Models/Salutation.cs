﻿namespace EmployeeTask.Models
{
    public class Salutation
    {
        public Int16 SalutationId { get; set; }
        public string SalutationName { get; set;}
    }
}
