﻿namespace EmployeeTask.Models
{
    public class Department
    {
        public Int16 DepartmentId { get; set; }
        public int EmployeeId { get; set; } 
        public string DepartmentName { get; set; }
    }
}
