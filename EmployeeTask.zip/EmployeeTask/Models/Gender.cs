﻿namespace EmployeeTask.Models
{
    public class Gender
    {
        public Int16 GenderId { get; set; }
        public string GenderName { get; set; }
    }
}
