﻿using EmployeeTask.Data;
using EmployeeTask.Models;
using EmployeeTask.Services.Implementations;
using Microsoft.EntityFrameworkCore;

namespace EmployeeTask.Services.Interfaces
{
    public interface IDepartmentService
    {
        Task<IEnumerable<Department>> GetAllDepartmentsAsync();
        Task<Department> GetDepartmentByIdAsync(Int16 id);
        Task CreateDepartmentAsync(Department department);
        Task UpdateDepartmentAsync(Department department);
        Task DeleteDepartmentAsync(Int16 id);
    }
}
