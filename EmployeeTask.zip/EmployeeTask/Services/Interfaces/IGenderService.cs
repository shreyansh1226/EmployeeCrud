﻿using EmployeeTask.Models;

namespace EmployeeTask.Services.Interfaces
{
    public interface IGenderService
    {
        Task<IEnumerable<Gender>> GetAllGendersAsync();
        Task<Gender> GetGenderByIdAsync(int id);
        Task<Gender> CreateGenderAsync(Gender gender);
        Task UpdateGenderAsync(Gender gender);
        Task DeleteGenderAsync(int id);
    }
}
