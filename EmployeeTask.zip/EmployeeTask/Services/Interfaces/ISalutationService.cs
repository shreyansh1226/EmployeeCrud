﻿using EmployeeTask.Models;

namespace EmployeeTask.Services.Interfaces
{
    public interface ISalutationService
    {
        Task<IEnumerable<Salutation>> GetAllSalutationsAsync();
        Task<Salutation> GetSalutationByIdAsync(int id);
        Task<Salutation> CreateSalutationAsync(Salutation salutation);
        Task UpdateSalutationAsync(Salutation salutation);
        Task DeleteSalutationAsync(int id);
    }
}
