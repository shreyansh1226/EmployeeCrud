﻿using EmployeeTask.Data;
using EmployeeTask.Models;
using EmployeeTask.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace EmployeeTask.Services.Implementations
{
    public class SalutationService : ISalutationService
    {
        private readonly MyDbContext _context;

        public SalutationService(MyDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Salutation>> GetAllSalutationsAsync()
        {
            return await _context.Salutations.ToListAsync();
        }

        public async Task<Salutation> GetSalutationByIdAsync(int id)
        {
            return await _context.Salutations.FindAsync(id);
        }

        public async Task<Salutation> CreateSalutationAsync(Salutation salutation)
        {
            if (salutation == null)
            {
                throw new ArgumentNullException(nameof(salutation));
            }

            _context.Salutations.Add(salutation);
            await _context.SaveChangesAsync();

            return salutation;
        }

        public async Task UpdateSalutationAsync(Salutation salutation)
        {
            if (salutation == null)
            {
                throw new ArgumentNullException(nameof(salutation));
            }

            var existingSalutation = await _context.Salutations.FindAsync(salutation.SalutationId);

            if (existingSalutation == null)
            {
                throw new ArgumentException("Salutation not found", nameof(salutation.SalutationId));
            }

            _context.Entry(existingSalutation).CurrentValues.SetValues(salutation);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteSalutationAsync(int id)
        {
            var salutation = await _context.Salutations.FindAsync(id);
            if (salutation == null)
            {
                throw new ArgumentException("Salutation not found", nameof(id));
            }

            _context.Salutations.Remove(salutation);
            await _context.SaveChangesAsync();
        }
    }
}
