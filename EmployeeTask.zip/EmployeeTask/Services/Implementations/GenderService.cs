﻿using EmployeeTask.Data;
using EmployeeTask.Models;
using EmployeeTask.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace EmployeeTask.Services.Implementations
{
    public class GenderService : IGenderService
    {
        private readonly MyDbContext _context;

        public GenderService(MyDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Gender>> GetAllGendersAsync()
        {
            return await _context.Genders.ToListAsync();
        }

        public async Task<Gender> GetGenderByIdAsync(int id)
        {
            return await _context.Genders.FindAsync(id);
        }

        public async Task<Gender> CreateGenderAsync(Gender gender)
        {
            if (gender == null)
            {
                throw new ArgumentNullException(nameof(gender));
            }

            _context.Genders.Add(gender);
            await _context.SaveChangesAsync();

            return gender;
        }

        public async Task UpdateGenderAsync(Gender gender)
        {
            if (gender == null)
            {
                throw new ArgumentNullException(nameof(gender));
            }

            var existingGender = await _context.Genders.FindAsync(gender.GenderId);

            if (existingGender == null)
            {
                throw new ArgumentException("Gender not found", nameof(gender.GenderId));
            }

            _context.Entry(existingGender).CurrentValues.SetValues(gender);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteGenderAsync(int id)
        {
            var gender = await _context.Genders.FindAsync(id);
            if (gender == null)
            {
                throw new ArgumentException("Gender not found", nameof(id));
            }

            _context.Genders.Remove(gender);
            await _context.SaveChangesAsync();
        }
    }
}
