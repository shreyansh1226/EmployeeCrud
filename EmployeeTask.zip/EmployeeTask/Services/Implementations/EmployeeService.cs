﻿using EmployeeTask.Repositories.Interfaces;
using EmployeeTask.Services.Interfaces;

namespace EmployeeTask.Services.Implementations
{
    public class EmployeeService : IEmployeeService
    {
        private readonly IEmployeeRepository _employeeRepository;

        public EmployeeService(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }

        public async Task<Employee> GetByIdAsync(int id)
        {
            return await _employeeRepository.GetByIdAsync(id);
        }

        public async Task<IEnumerable<Employee>> GetAllAsync()
        {
            return await _employeeRepository.GetAllAsync();
        }

        public async Task CreateEmployeeAsync(Employee employee)
        {
            ValidateEmployee(employee);
            await _employeeRepository.CreateAsync(employee);
        }

        public async Task UpdateEmployeeAsync(Employee employee)
        {
            ValidateEmployee(employee);
            await _employeeRepository.UpdateAsync(employee);
        }

        public async Task DeleteEmployeeAsync(int id)
        {
            var existingEmployee = await _employeeRepository.GetByIdAsync(id);

            if (existingEmployee == null)
            {
                throw new ArgumentException("Employee not found", nameof(id));
            }

            await _employeeRepository.DeleteAsync(id);
        }

        private void ValidateEmployee(Employee employee)
        {
            if (employee == null)
            {
                throw new ArgumentNullException(nameof(employee));
            }

            var validationErrors = new List<string>();

            if (string.IsNullOrWhiteSpace(employee.EmployeeCode))
            {
                validationErrors.Add("EmployeeCode is required.");
            }

            if (string.IsNullOrWhiteSpace(employee.FirstName))
            {
                validationErrors.Add("FirstName is required.");
            }

            if (string.IsNullOrWhiteSpace(employee.LastName))
            {
                validationErrors.Add("LastName is required.");
            }

            if (employee.SalutationId <= 0)
            {
                validationErrors.Add("SalutationId is required and must be greater than 0.");
            }

            if (employee.DepartmentId <= 0)
            {
                validationErrors.Add("DepartmentId is required and must be greater than 0.");
            }

            if (employee.GenderId <= 0)
            {
                validationErrors.Add("GenderId is required and must be greater than 0.");
            }

            if (employee.DOB == default)
            {
                validationErrors.Add("DOB is required.");
            }

            if (employee.MaritalStatus == default)
            {
                validationErrors.Add("MaritalStatus is required.");
            }

            if (employee.DOJ != null && employee.DOJ < employee.DOB)
            {
                validationErrors.Add("DOJ cannot be before DOB.");
            }

            if (string.IsNullOrWhiteSpace(employee.PanNo))
            {
                validationErrors.Add("PANNo is required.");
            }

            if (string.IsNullOrWhiteSpace(employee.AadharNo))
            {
                validationErrors.Add("AADHARNo is required.");
            }

            if (string.IsNullOrWhiteSpace(employee.Description))
            {
                validationErrors.Add("Description is required.");
            }

            if (validationErrors.Any())
            {
                throw new ArgumentException(string.Join(" ", validationErrors));
            }
        }
    }
}
