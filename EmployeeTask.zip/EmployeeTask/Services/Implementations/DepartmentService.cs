﻿using EmployeeTask.Data;
using EmployeeTask.Models;
using EmployeeTask.Repositories.Interfaces;
using EmployeeTask.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace EmployeeTask.Services.Implementations
{
    public class DepartmentService : IDepartmentService
    {
        private readonly IDepartmentRepository _departmentRepository;

        public DepartmentService(IDepartmentRepository departmentRepository)
        {
            _departmentRepository = departmentRepository;
        }

        public async Task<IEnumerable<Department>> GetAllDepartmentsAsync()
        {
            return await _departmentRepository.GetAllAsync();
        }

        public async Task<Department> GetDepartmentByIdAsync(Int16 id)
        {
            return await _departmentRepository.GetByIdAsync(id);
        }

        public async Task CreateDepartmentAsync(Department department)
        {
            if (department == null)
            {
                throw new ArgumentNullException(nameof(department));
            }

            await _departmentRepository.CreateAsync(department);
        }

        public async Task UpdateDepartmentAsync(Department department)
        {
            if (department == null)
            {
                throw new ArgumentNullException(nameof(department));
            }

            await _departmentRepository.UpdateAsync(department);
        }

        public async Task DeleteDepartmentAsync(Int16 id)
        {
            await _departmentRepository.DeleteAsync(id);
        }
    }
}
