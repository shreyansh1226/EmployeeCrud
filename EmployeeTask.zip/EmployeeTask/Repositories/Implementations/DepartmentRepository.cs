﻿using EmployeeTask.Data;
using EmployeeTask.Models;
using EmployeeTask.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace EmployeeTask.Repositories.Implementations
{
    public class DepartmentRepository : IDepartmentRepository
    {
        private readonly MyDbContext _context;

        public DepartmentRepository(MyDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Department>> GetAllAsync()
        {
            return await _context.Departments.ToListAsync();
        }

        public async Task<Department> GetByIdAsync(Int16 id)
        {
            return await _context.Departments.FindAsync(id);
        }

        public async Task CreateAsync(Department department)
        {
            if (department == null)
            {
                throw new ArgumentNullException(nameof(department));
            }

            _context.Departments.Add(department);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Department department)
        {
            if (department == null)
            {
                throw new ArgumentNullException(nameof(department));
            }

            var existingDepartment = await _context.Departments.FindAsync(department.DepartmentId);

            if (existingDepartment == null)
            {
                throw new ArgumentException("Department not found", nameof(department.DepartmentId));
            }

            _context.Entry(existingDepartment).CurrentValues.SetValues(department);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Int16 id)
        {
            var department = await _context.Departments.FindAsync(id);
            if (department == null)
            {
                throw new ArgumentException("Department not found", nameof(id));
            }

            _context.Departments.Remove(department);
            await _context.SaveChangesAsync();
        }
    }
}
