﻿using EmployeeTask.Data;
using EmployeeTask.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace EmployeeTask.Repositories.Implementations
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly MyDbContext _context;

        public EmployeeRepository(MyDbContext context)
        {
            _context = context;
        }

        public async Task<Employee> GetByIdAsync(int id)
        {
            return await _context.Employees.FindAsync(id);
        }

        public async Task<IEnumerable<Employee>> GetAllAsync()
        {
            return await _context.Employees.ToListAsync();
        }

        public async Task CreateAsync(Employee employee)
        {
            if (employee == null)
            {
                throw new ArgumentNullException(nameof(employee));
            }
            if (await _context.Employees.AnyAsync(e => e.EmployeeCode == employee.EmployeeCode))
            {
                throw new InvalidOperationException("EmployeeCode must be unique.");
            }
            _context.Employees.Add(employee);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Employee employee)
        {
            if (employee == null)
            {
                throw new ArgumentNullException(nameof(employee));
            }

            var existingEmployee = await _context.Employees.FindAsync(employee.EmployeeId);

            if (existingEmployee == null)
            {
                throw new ArgumentException("Employee not found", nameof(employee.EmployeeId));
            }
            if (await _context.Employees.AnyAsync(e => e.EmployeeCode == employee.EmployeeCode && e.EmployeeId != employee.EmployeeId))
            {
                throw new InvalidOperationException("EmployeeCode must be unique.");
            }
            _context.Entry(existingEmployee).CurrentValues.SetValues(employee);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee == null)
            {
                throw new ArgumentException("Employee not found", nameof(id));
            }

            _context.Employees.Remove(employee);
            await _context.SaveChangesAsync();
        }
    }

}
