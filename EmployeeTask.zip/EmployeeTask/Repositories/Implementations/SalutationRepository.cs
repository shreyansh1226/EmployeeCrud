﻿using EmployeeTask.Data;
using EmployeeTask.Models;
using EmployeeTask.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace EmployeeTask.Repositories.Implementations
{
    public class SalutationRepository : ISalutationRepository
    {
        private readonly MyDbContext _context;

        public SalutationRepository(MyDbContext context)
        {
            _context = context;
        }

        public async Task<Salutation> GetByIdAsync(int id)
        {
            return await _context.Salutations.FindAsync(id);
        }

        public async Task<IEnumerable<Salutation>> GetAllAsync()
        {
            return await _context.Salutations.ToListAsync();
        }

        public async Task CreateAsync(Salutation salutation)
        {
            if (salutation == null)
            {
                throw new ArgumentNullException(nameof(salutation));
            }

            // You can add custom validation checks here

            _context.Salutations.Add(salutation);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Salutation salutation)
        {
            if (salutation == null)
            {
                throw new ArgumentNullException(nameof(salutation));
            }

            var existingSalutation = await _context.Salutations.FindAsync(salutation.SalutationId);

            if (existingSalutation == null)
            {
                throw new ArgumentException("Salutation not found", nameof(salutation.SalutationId));
            }

            // You can add custom validation checks here

            _context.Entry(existingSalutation).CurrentValues.SetValues(salutation);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var salutation = await _context.Salutations.FindAsync(id);
            if (salutation == null)
            {
                throw new ArgumentException("Salutation not found", nameof(id));
            }

            _context.Salutations.Remove(salutation);
            await _context.SaveChangesAsync();
        }
    }
}
