﻿using EmployeeTask.Data;
using EmployeeTask.Models;
using EmployeeTask.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace EmployeeTask.Repositories.Implementations
{
    public class GenderRepository : IGenderRepository
    {
        private readonly MyDbContext _context;

        public GenderRepository(MyDbContext context)
        {
            _context = context;
        }

        public async Task<Gender> GetByIdAsync(int id)
        {
            return await _context.Genders.FindAsync(id);
        }

        public async Task<IEnumerable<Gender>> GetAllAsync()
        {
            return await _context.Genders.ToListAsync();
        }

        public async Task CreateAsync(Gender gender)
        {
            if (gender == null)
            {
                throw new ArgumentNullException(nameof(gender));
            }

            // You can add custom validation checks here

            _context.Genders.Add(gender);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Gender gender)
        {
            if (gender == null)
            {
                throw new ArgumentNullException(nameof(gender));
            }

            var existingGender = await _context.Genders.FindAsync(gender.GenderId);

            if (existingGender == null)
            {
                throw new ArgumentException("Gender not found", nameof(gender.GenderId));
            }

            // You can add custom validation checks here

            _context.Entry(existingGender).CurrentValues.SetValues(gender);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var gender = await _context.Genders.FindAsync(id);
            if (gender == null)
            {
                throw new ArgumentException("Gender not found", nameof(id));
            }

            _context.Genders.Remove(gender);
            await _context.SaveChangesAsync();
        }
    }
}
