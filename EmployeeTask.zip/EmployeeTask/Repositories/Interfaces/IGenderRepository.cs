﻿using EmployeeTask.Models;

namespace EmployeeTask.Repositories.Interfaces
{
    public interface IGenderRepository
    {
        Task<Gender> GetByIdAsync(int id);
        Task<IEnumerable<Gender>> GetAllAsync();
        Task CreateAsync(Gender gender);
        Task UpdateAsync(Gender gender);
        Task DeleteAsync(int id);
    }
}
