﻿using EmployeeTask.Models;

namespace EmployeeTask.Repositories.Interfaces
{
    public interface ISalutationRepository
    {
        Task<Salutation> GetByIdAsync(int id);
        Task<IEnumerable<Salutation>> GetAllAsync();
        Task CreateAsync(Salutation salutation);
        Task UpdateAsync(Salutation salutation);
        Task DeleteAsync(int id);
    }
}
