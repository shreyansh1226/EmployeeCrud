﻿using EmployeeTask.Models;
using Microsoft.EntityFrameworkCore;

namespace EmployeeTask.Data
{
    public class MyDbContext :DbContext
    {
        public MyDbContext(DbContextOptions<MyDbContext> options) : base(options) { }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Salutation> Salutations { get; set; }
        public DbSet<Gender> Genders { get; set; }
        public DbSet<Department> Departments { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure relationships, constraints, and unique keys here.

            // Configure Employee-Salutation relationship
            modelBuilder.Entity<Employee>()
                .HasOne(e => e.Salutation)
                .WithMany()
                .HasForeignKey(e => e.SalutationId);

            // Configure Employee-Department relationship
            modelBuilder.Entity<Employee>()
                .HasOne(e => e.Department)
                .WithMany()
                .HasForeignKey(e => e.DepartmentId);

            // Configure Employee-Gender relationship
            modelBuilder.Entity<Employee>()
                .HasOne(e => e.Gender)
                .WithMany()
                .HasForeignKey(e => e.GenderId);

            // Configure unique constraint for EmployeeCode
            modelBuilder.Entity<Employee>()
                .HasIndex(e => e.EmployeeCode)
                .IsUnique();

            // Configure unique constraint for PANNo
            modelBuilder.Entity<Employee>()
                .HasIndex(e => e.PanNo)
                .IsUnique();

            // Configure unique constraint for AADHARNo
            modelBuilder.Entity<Employee>()
                .HasIndex(e => e.AadharNo)
                .IsUnique();
        }

    }
}
